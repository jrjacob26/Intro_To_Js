    // JavaScript to display the welcome alert
    window.onload = function() {
        var userName = prompt("Enter your name:");
        alert("Welcome to " + (userName || "User/Student"));
    }

    // JavaScript to print the student information table
    function printStudentList() {
        var printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Student Information</title></head><body>');

        var tableHtml = document.getElementById('studentTable').outerHTML;
        printWindow.document.write('<h2>Student Information List</h2>');
        printWindow.document.write(tableHtml);

        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    }